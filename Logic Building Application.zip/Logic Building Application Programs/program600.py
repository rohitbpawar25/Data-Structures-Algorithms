


print("Jay Ganesh...")